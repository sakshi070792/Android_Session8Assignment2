package com.mani.session8ass2;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int result_settings=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.settings,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_settings:
                Intent i=new Intent(this,UserSettingActivity.class);
                startActivityForResult(i,result_settings);
                break;
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case result_settings:
                showusersettings();
                break;
        }
    }

    private void showusersettings() {
        SharedPreferences sharedpref= PreferenceManager.getDefaultSharedPreferences(this);
        StringBuilder builder=new StringBuilder();
        builder.append("\n Password:"+sharedpref.getString("prefpass",null));
        builder.append("\n ScreenLock:"+sharedpref.getBoolean("ScreenLock",false));
        builder.append("\n Update Frequency:"+sharedpref.getString("prefsyncfrequency",null));
        TextView settingtextview=(TextView)findViewById(R.id.textusersettings);
        settingtextview.setText(builder.toString());

    }
}
