package com.mani.session8ass2;

import android.os.Bundle;
import android.preference.PreferenceActivity;

/**
 * Created by sakshi.banger on 22-09-2016.
 */
public class UserSettingActivity extends PreferenceActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.settings);
    }
}
